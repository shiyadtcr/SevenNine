import { Injectable,EventEmitter } from '@angular/core';
import { NgbModal, ModalDismissReasons, NgbDateStruct, NgbCalendar } from '@ng-bootstrap/ng-bootstrap';

@Injectable()
export class AppService {
  closeResult: string;
  testEmit : EventEmitter<any> = new EventEmitter<any>();
  
  constructor(
    private modalService: NgbModal
  ) { }
  openPopup(content,options){
    this.modalService.open(content,options).result.then((result) => {
        this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
        this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  getDismissReason(reason: any): string {
        if (reason === ModalDismissReasons.ESC) {
            return 'by pressing ESC';
        } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
            return 'by clicking on a backdrop';
        } else {
            return  `with: ${reason}`;
        }
    }
  setSessionData(k,v){
    sessionStorage.setItem(k,v);
  }
  getSessionData(k){
    return sessionStorage.getItem(k);
  }
  removeSessionData(k){
    return sessionStorage.removeItem(k);
  }
  clearSessionData(k){
    return sessionStorage.clear();
  }
}
