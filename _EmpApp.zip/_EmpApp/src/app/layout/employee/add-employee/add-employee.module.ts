import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

import { AddEmployeeRoutingModule } from './add-employee-routing.module';
import { AddEmployeeComponent } from './add-employee.component';

@NgModule({
  imports: [
    CommonModule, AddEmployeeRoutingModule, FormsModule, ReactiveFormsModule
  ],
  declarations: [ AddEmployeeComponent ]
})
export class AddEmployeeModule { }
