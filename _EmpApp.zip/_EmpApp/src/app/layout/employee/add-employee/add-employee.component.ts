import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { routerTransition } from '../../../router.animations';
import { AppService } from '../../../shared';
import { EmployeeService } from '../employee.service';
@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.scss'],
  animations: [routerTransition()]
})
export class AddEmployeeComponent implements OnInit {
  employeeAddressFormGroup:FormGroup;
  selectedEditEmployee:string = 'Employee';
  editMode:string = 'false';
  constructor(
    private addressForm: FormBuilder,
    private appService:AppService,
    private employeeService:EmployeeService
  ) {     
    this.selectedEditEmployee = this.appService.getSessionData('selected-employee-title');
    this.editMode = this.appService.getSessionData  ('edit-employee-mode');
    this.employeeAddressFormGroup = this.addressForm.group({
      area: ['', Validators.required ],
      addrLine1: ['', Validators.required ],
      addrLine2: [''],
      city: ['', Validators.required ],
      username: ['', Validators.required ],
      pwd: ['', Validators.required ],
      image: [''],
      pin: ['', Validators.required ],
      phone: [''],
      mob: ['', Validators.required ],
      fax: [''],
      contactPerson: ['', Validators.required ],
      email: ['', Validators.required ]
    });
  }
  get _area() { return this.employeeAddressFormGroup.get('area'); }
  get _addrLine1() { return this.employeeAddressFormGroup.get('addrLine1'); }
  get _addrLine2() { return this.employeeAddressFormGroup.get('addrLine2'); }
  get _city() { return this.employeeAddressFormGroup.get('city'); }
  get _username() { return this.employeeAddressFormGroup.get('username'); }
  get _pwd() { return this.employeeAddressFormGroup.get('pwd'); }
  get _image() { return this.employeeAddressFormGroup.get('image'); }
  get _pin() { return this.employeeAddressFormGroup.get('pin'); }
  get _phone() { return this.employeeAddressFormGroup.get('phone'); }
  get _mob() { return this.employeeAddressFormGroup.get('mob'); }
  get _fax() { return this.employeeAddressFormGroup.get('fax'); }
  get _contactPerson() { return this.employeeAddressFormGroup.get('contactPerson'); }
  get _email() { return this.employeeAddressFormGroup.get('email'); }
  set _area(value:any) { this._area.value = value; }
  set _addrLine1(value:any) { this._addrLine1.value = value; }
  set _addrLine2(value:any) { this._area.value = value; }
  set _city(value:any) { this._area.value = value; }
  set _username(value:any) { this._area.value = value; }
  set _pwd(value:any) { this._area.value = value; }
  set _image(value:any) { this._area.value = value; }
  set _pin(value:any) { this._area.value = value; }
  set _phone(value:any) { this._area.value = value; }
  set _mob(value:any) { this._area.value = value; }
  set _fax(value:any) { this._area.value = value; }
  set _contactPerson(value:any) { this._area.value = value; }  
  set _email(value:any) { this._area.value = value; }
  isError(field){
	  return field.invalid && (field.dirty || field.touched);
  }
  onSubmitEmployee(){
    let _employeeArrd = {
      area:this._area.value,		
      addrLine1:this._addrLine1.value,
      addrLine2:this._addrLine2.value,
      city:this._city.value,
      username:this._username.value,
      pwd:this._pwd.value,
      image:this._image.value,
      pin:this._pin.value,
      phone:this._phone.value,
      mob:this._mob.value,
      fax:this._fax.value,
      contactPerson:this._contactPerson.value,
      email:this._email.value
	  }
    console.log('Employee Form Request Data: ',_employeeArrd);
  }
  ngOnInit() {
    if(this.editMode == 'true'){
      let employeeData = this.employeeService.getEmployeeDetailsById('');
      this._area.value = employeeData.area;
      this._addrLine1.value = employeeData.addrLine1;
      this._addrLine2.value = employeeData.addrLine2;
      this._city.value = employeeData.city;
      this._username.value = employeeData.username;
      this._pwd.value = employeeData.pwd;
      this._image.value = employeeData.image;
      this._pin.value = employeeData.pin;
      this._phone.value = employeeData.phone;
      this._mob.value = employeeData.mob;
      this._fax.value = employeeData.fax;
      this._contactPerson.value = employeeData.contactPerson;
      this._email.value = employeeData.email;
    }
  }
  ngOnDestroy(){
    this.appService.setSessionData('edit-employee-mode',false);
  }

}
