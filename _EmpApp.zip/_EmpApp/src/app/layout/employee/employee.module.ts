import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TranslateModule } from '@ngx-translate/core';
import { EmployeeService } from './employee.service';
import { EmployeeRoutingModule } from './employee-routing.module';
import { SharedComponentModule } from '../components/shared-component.module';
import { EmployeeComponent } from './employee.component';
import { AppService } from '../../shared';


@NgModule({
  imports: [
    CommonModule, EmployeeRoutingModule, TranslateModule, SharedComponentModule
  ],
  declarations: [ EmployeeComponent ],
  providers: [ EmployeeService ]
})
export class EmployeeModule { 
  constructor(
    private appService:AppService
  ) { 
    this.appService.setSessionData('main-module','employee');
  }
}
