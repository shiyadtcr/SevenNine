import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { EmployeeComponent } from './employee.component';

const routes: Routes = [
	{
		path: '',
		component: EmployeeComponent,
		children: [
			{ path: '', redirectTo: 'home' },
			{ path: 'home', loadChildren: './home/employee-list.module#EmployeeListModule'},
			{ path: 'add', loadChildren: './add-employee/add-employee.module#AddEmployeeModule'}
		]
	}
];
@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  exports:[ RouterModule ],
  declarations: []
})
export class EmployeeRoutingModule { }
