import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from '../../../../../shared';

@Component({
    selector: 'app-stat-employee',
    templateUrl: './stat-employee.component.html',
    styleUrls: ['./stat-employee.component.scss']
})
export class StatEmployeeComponent implements OnInit {
    @Input() bgClass: string;
    @Input() icon: string;
    @Input() count: number;
    @Input() label: string;
    @Input() data: number;
    @Input() employeeData: any;
    @Output() event: EventEmitter<any> = new EventEmitter();

    constructor(
        private router : Router,
        private appService:AppService
    ) {}
    setSelectedEmployee(){
        this.appService.setSessionData('selected-employee-id',this.employeeData.id);
        this.appService.setSessionData('selected-employee-title',this.employeeData.title);
    }
    navigateToEmployee(){
        this.setSelectedEmployee();
        this.router.navigate(['../employee','/home']);
    }
    editEmployee(){
        this.setSelectedEmployee();
        this.appService.setSessionData('edit-employee-mode',true);
        this.router.navigate(['employee','add']);
    }
    ngOnInit() {}
}
