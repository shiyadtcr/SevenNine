import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StatComponent } from './stat-employee.component';

describe('StatEmployeeComponent', () => {
    let component: StatEmployeeComponent;
    let fixture: ComponentFixture<StatComponent>;

    beforeEach(
        async(() => {
            TestBed.configureTestingModule({
                declarations: [StatEmployeeComponent]
            }).compileComponents();
        })
    );

    beforeEach(() => {
        fixture = TestBed.createComponent(StatEmployeeComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
