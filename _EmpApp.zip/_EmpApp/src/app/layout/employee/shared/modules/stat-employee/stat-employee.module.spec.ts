import { StatModule } from './stat-employee.module';

describe('StatEmployeeModule', () => {
    let statEmployeeModule: StatEmployeeModule;

    beforeEach(() => {
        statEmployeeModule = new StatEmployeeModule();
    });

    it('should create an instance', () => {
        expect(statEmployeeModule).toBeTruthy();
    });
});
