import { Injectable } from '@angular/core';

@Injectable()
export class EmployeeService {
allEmployees: any = [
    {
      id:1,
      title:'Shiyad C K',
      logo:'assets/images/employees/dummy.png',
      dept:'Humon Resource',
      description:'Test 123'
    },
    {
      id:2,
      title:'Jomi N J',
      logo:'assets/images/employees/dummy.png',
      dept:'Humon Resource',
      description:'Test 123'
    }
  ];
  employeeDetails:any = {
    area:'Kunnamkulam',
    addrLine1:'Cherath (H)',
    addrLine2:'Korattikkara PO',
    city:'Thrissur',
    username:'shiyad',
    pwd:'Test@123',
    image:'',
    pin:'680543',
    phone:'0000',
    mob:'+918129796790',
    fax:'0000',
    contactPerson:'jomi',
    email:'shiyad.tcr@gmail.com'
  };
  constructor() { }
  getEmployeeDetailsById(id){
    return this.employeeDetails;
  }
  getAllEmployees(){
    return this.allEmployees;
  }
}
