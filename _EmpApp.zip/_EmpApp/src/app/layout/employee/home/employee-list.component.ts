import { Component, OnInit } from '@angular/core';
import { routerTransition } from '../../../router.animations';
import { AppService } from '../../../shared';
import { EmployeeService } from '../employee.service';
@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.scss'],
  animations: [routerTransition()]
})
export class EmployeeListComponent implements OnInit {
  pageTitle:string  =   'Employees';
  selectedBranch:string = '';
  employeeList:any;
  constructor(
    private appService:AppService,
    private employeeService:EmployeeService
  ) {
    this.employeeList = this.employeeService.getAllEmployees();
    if(this.appService.getSessionData('selected-branch-id')){
      this.selectedBranch = this.appService.getSessionData('selected-branch-id');
      this.pageTitle = this.appService.getSessionData('selected-branch-title');
    }
   }

  ngOnInit() {
  }

}
