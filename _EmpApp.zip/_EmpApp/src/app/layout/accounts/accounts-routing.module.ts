import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AccountsComponent } from './accounts.component';

const routes: Routes = [
	{
		path: '',
		component: AccountsComponent,
		children: [
			{ path: '', redirectTo: 'home' },
			{ path: 'home', loadChildren: './home/accounts-home.module#AccountsHomeModule'}
		]
	}
];
@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  declarations: []
})
export class AccountsRoutingModule { }
