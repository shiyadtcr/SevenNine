import { Component, OnInit } from '@angular/core';
import { routerTransition } from '../../../router.animations';
import { AppService } from '../../../shared';
@Component({
  selector: 'app-accounts-home',
  templateUrl: './accounts-home.component.html',
  styleUrls: ['./accounts-home.component.scss'],
  animations: [routerTransition()]
})
export class AccountsHomeComponent implements OnInit {

  pageTitle:string  =   'Accounts';
  selectedBranch:string = '';
  accountsList:any = [
    {
      id:1,
      title:'Pending Invoice',
      logo:'assets/images/employees/dummy.png',
      count:5,
      description:'Test 123'
    },
    {
      id:2,
      title:'Paid Invoice',
      logo:'assets/images/employees/dummy.png',
      count:10,
      description:'Test 123'
    },
    {
      id:2,
      title:'Timesheet',
      logo:'assets/images/employees/dummy.png',
      count:5,
      description:'Test 123'
    }
  ]
  constructor(
    private appService:AppService
  ) {
    this.appService.setSessionData('main-module','accounts');
    if(this.appService.getSessionData('selected-branch-id')){
      this.selectedBranch = this.appService.getSessionData('selected-branch-id');
      this.pageTitle = this.appService.getSessionData('selected-branch-title');
    }
   }

  ngOnInit() {
  }

}
