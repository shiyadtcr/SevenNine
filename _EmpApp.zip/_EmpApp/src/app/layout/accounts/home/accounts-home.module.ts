import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AccountsHomeRoutingModule } from './accounts-home-routing.module';
import { AccountsHomeComponent } from './accounts-home.component';
import { StatAccountsModule } from '../shared';

@NgModule({
  imports: [
    CommonModule, AccountsHomeRoutingModule, StatAccountsModule
  ],
  declarations: [AccountsHomeComponent]
})
export class AccountsHomeModule { }
