import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TranslateModule } from '@ngx-translate/core';
import { AccountsService } from './accounts.service';
import { AccountsRoutingModule } from './accounts-routing.module';
import { SharedComponentModule } from '../components/shared-component.module';
import { AccountsComponent } from './accounts.component';
import { AppService } from '../../shared';



@NgModule({
  imports: [
    CommonModule, AccountsRoutingModule, TranslateModule, SharedComponentModule
  ],
  declarations: [ AccountsComponent ]
})
export class AccountsModule { 
  constructor(
    private appService:AppService
  ) { 
    this.appService.setSessionData('main-module','accounts');
  }
}
