import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StatComponent } from './stat-accounts.component';

describe('StatAccountsComponent', () => {
    let component: StatAccountsComponent;
    let fixture: ComponentFixture<StatComponent>;

    beforeEach(
        async(() => {
            TestBed.configureTestingModule({
                declarations: [StatAccountsComponent]
            }).compileComponents();
        })
    );

    beforeEach(() => {
        fixture = TestBed.createComponent(StatAccountsComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
