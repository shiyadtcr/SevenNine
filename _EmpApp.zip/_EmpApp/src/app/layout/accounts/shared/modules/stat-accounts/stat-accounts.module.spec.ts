import { StatModule } from './stat-accounts.module';

describe('StatAccountsModule', () => {
    let StatAccountsModule: StatAccountsModule;

    beforeEach(() => {
        StatAccountsModule = new StatAccountsModule();
    });

    it('should create an instance', () => {
        expect(StatAccountsModule).toBeTruthy();
    });
});
