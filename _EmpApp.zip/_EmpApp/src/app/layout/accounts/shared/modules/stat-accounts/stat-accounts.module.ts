import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { StatAccountsComponent } from './stat-accounts.component';

@NgModule({
    imports: [CommonModule, RouterModule],
    declarations: [StatAccountsComponent],
    exports: [StatAccountsComponent]
})
export class StatAccountsModule {}
