import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { RouterModule } from '@angular/router';
import { AppService } from '../../shared';

import { SubHeaderComponent } from './sub-header/sub-header.component';
import { SidebarComponent } from './sidebar/sidebar.component';
@NgModule({
  imports: [
    CommonModule, TranslateModule, RouterModule
  ],
  declarations: [ 
    SidebarComponent, SubHeaderComponent
  ],
  exports: [
    SidebarComponent, SubHeaderComponent, TranslateModule, RouterModule, 
  ],
  providers: [AppService]
})
export class SharedComponentModule { }
