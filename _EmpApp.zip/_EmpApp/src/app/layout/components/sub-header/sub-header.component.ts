import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { AppService } from '../../../shared';

@Component({
    selector: 'app-sub-header',
    templateUrl: './sub-header.component.html',
    styleUrls: ['./sub-header.component.scss']
})
export class SubHeaderComponent implements OnInit {
    navHeight:number = 0;
    hasClientSelected:string = '';
    constructor(private translate: TranslateService, public router: Router, private appService: AppService) {

        this.translate.addLangs(['en', 'fr', 'ur', 'es', 'it', 'fa', 'de', 'zh-CHS']);
        this.translate.setDefaultLang('en');
        const browserLang = this.translate.getBrowserLang();
        this.translate.use(browserLang.match(/en|fr|ur|es|it|fa|de|zh-CHS/) ? browserLang : 'en');

        this.router.events.subscribe(val => {
            if (
                val instanceof NavigationEnd
            ) {
               this.hasClientSelected = this.appService.getSessionData('hasClientSelected');
            } 
        });

    }

    ngOnInit() {}
    getActiveClass(v){
        let _active = '';
        let _url = this.router.url;
        if(_url.indexOf(v) != -1){
            _active = 'active'
        }
        return _active;
    }
    toggleMenu() {
        this.navHeight  = this.navHeight == 0 ? 350 : 0;
    }

    changeLang(language: string) {
        this.translate.use(language);
    }
}
