import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { AppService } from '../../../shared';

@Component({
    selector: 'app-sidebar',
    templateUrl: './sidebar.component.html',
    styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent {
    isActive: boolean = false;
    showMenu: string = '';
    pushRightClass: string = 'push-right';
    selectedModule:string = '';
    selectedItemTitle:string = '';
    constructor(private translate: TranslateService, public router: Router, private appService:AppService) {
        this.translate.addLangs(['en', 'fr', 'ur', 'es', 'it', 'fa', 'de']);
        this.translate.setDefaultLang('en');
        const browserLang = this.translate.getBrowserLang();
        this.translate.use(browserLang.match(/en|fr|ur|es|it|fa|de/) ? browserLang : 'en');

        this.router.events.subscribe(val => {
            if (
                val instanceof NavigationEnd &&
                window.innerWidth <= 992 &&
                this.isToggled()
            ) {
                this.toggleSidebar();
            } else if (
                val instanceof NavigationEnd
            ){
                if(val.urlAfterRedirects.indexOf('branch') != -1) {
                    this.selectedModule = 'branch';
                    this.appService.setSessionData('main-module','branch');
                    this.selectedItemTitle = this.appService.getSessionData('selected-branch-title');
                }
                if(val.urlAfterRedirects.indexOf('client') != -1) {
                    this.selectedModule = 'client';
                    this.appService.setSessionData('main-module','client');
                    this.selectedItemTitle = this.appService.getSessionData('selected-client-title');
                }
                if(val.urlAfterRedirects.indexOf('employee') != -1) {
                    this.selectedModule = 'employee';
                    this.appService.setSessionData('main-module','employee');
                    this.selectedItemTitle = this.appService.getSessionData('selected-employee-title');
                }
                if(val.urlAfterRedirects.indexOf('accounts') != -1) {
                    this.selectedModule = 'accounts';
                    this.appService.setSessionData('main-module','accounts');
                    this.selectedItemTitle = this.appService.getSessionData('selected-accounts-title');
                }
            }
        });
    }

    eventCalled() {
        this.isActive = !this.isActive;
    }

    addExpandClass(element: any) {
        if (element === this.showMenu) {
            this.showMenu = '0';
        } else {
            this.showMenu = element;
        }
    }

    isToggled(): boolean {
        const dom: Element = document.querySelector('body');
        return dom.classList.contains(this.pushRightClass);
    }

    toggleSidebar() {
        const dom: any = document.querySelector('body');
        dom.classList.toggle(this.pushRightClass);
    }

    rltAndLtr() {
        const dom: any = document.querySelector('body');
        dom.classList.toggle('rtl');
    }

    changeLang(language: string) {
        this.translate.use(language);
    }

    onLoggedout() {
        localStorage.removeItem('isLoggedin');
    }
}
