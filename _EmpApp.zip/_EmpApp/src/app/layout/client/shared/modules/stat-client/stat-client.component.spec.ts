import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StatComponent } from './stat-client.component';

describe('StatClientComponent', () => {
    let component: StatClientComponent;
    let fixture: ComponentFixture<StatClientComponent>;

    beforeEach(
        async(() => {
            TestBed.configureTestingModule({
                declarations: [StatClientComponent]
            }).compileComponents();
        })
    );

    beforeEach(() => {
        fixture = TestBed.createComponent(StatClientComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
