import { StatModule } from './stat-client.module';

describe('StatClientModule', () => {
    let statModule: StatClientModule;

    beforeEach(() => {
        statClientModule = new StatClientModule();
    });

    it('should create an instance', () => {
        expect(staClienttModule).toBeTruthy();
    });
});
