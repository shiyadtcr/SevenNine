import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from '../../../../../shared';

@Component({
    selector: 'app-stat-client',
    templateUrl: './stat-client.component.html',
    styleUrls: ['./stat-client.component.scss']
})
export class StatClientComponent implements OnInit {
    @Input() bgClass: string;
    @Input() icon: string;
    @Input() count: number;
    @Input() label: string;
    @Input() data: number;
    @Input() clientData: any;
    @Output() event: EventEmitter<any> = new EventEmitter();

    constructor(
        private router : Router,
        private appService:AppService
    ) {}
    setSelectedClient(){
        this.appService.setSessionData('selected-client-id',this.clientData.id);
        this.appService.setSessionData('selected-client-title',this.clientData.title);
        this.appService.setSessionData('hasClientSelected',true);
    }
    navigateToClientDetails(){
        this.setSelectedClient();
        this.router.navigate(['client/details']);
    }
    editClient(){
        this.setSelectedClient();
        this.appService.setSessionData('edit-client-mode',true);
        this.router.navigate(['client','add']);
    }
    ngOnInit() {}
}
