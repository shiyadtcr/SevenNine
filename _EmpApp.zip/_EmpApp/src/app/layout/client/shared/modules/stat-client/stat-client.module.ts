import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { StatClientComponent } from './stat-client.component';

@NgModule({
    imports: [CommonModule, RouterModule],
    declarations: [StatClientComponent],
    exports: [StatClientComponent]
})
export class StatClientModule {}
