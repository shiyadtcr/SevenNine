import { Component, OnInit, OnDestroy } from '@angular/core';
import { AppService } from '../../shared';

@Component({
  selector: 'app-client',
  templateUrl: './client.component.html',
  styleUrls: ['./client.component.scss']
})
export class ClientComponent implements OnInit {
  constructor(
    private appService: AppService
  ) { }
  ngOnInit() { }
  ngOnDestroy(){
    this.appService.removeSessionData('selected-client-id');
    this.appService.removeSessionData('hasClientSelected');
  }
}
