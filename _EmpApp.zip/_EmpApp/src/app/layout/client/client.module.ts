import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TranslateModule } from '@ngx-translate/core';
import { ClientService } from './client.service';
import { ClientRoutingModule } from './client-routing.module';
import { SharedComponentModule } from '../components/shared-component.module';
import { ClientComponent } from './client.component';
import { AppService } from '../../shared';

@NgModule({
  imports: [
    CommonModule, ClientRoutingModule, TranslateModule, SharedComponentModule
  ],
  declarations: [ ClientComponent ],
  providers: [ ClientService ]
})
export class ClientModule { 
  constructor(
    private appService:AppService
  ) { 
    this.appService.setSessionData('main-module','client'); 
  }
}
