import { Component, OnInit, OnDestroy } from '@angular/core';
import { AppService } from '../../../shared';

@Component({
  selector: 'app-client-info',
  templateUrl: './client-info.component.html',
  styleUrls: ['./client-info.component.scss']
})
export class ClientInfoComponent implements OnInit {

  constructor(
    private appService:AppService
  ) { }

  ngOnInit() {
  }
  ngOnDestroy() {
    this.appService.removeSessionData('hasClientSelected'); 
  }

}
