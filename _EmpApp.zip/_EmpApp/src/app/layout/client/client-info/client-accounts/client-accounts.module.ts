import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';


import { ClientAccountsRoutingModule } from './client-accounts-routing.module';
import { ClientAccountsComponent } from './client-accounts.component';

@NgModule({
  imports: [
    CommonModule, ClientAccountsRoutingModule
  ],
  declarations: [ ClientAccountsComponent ]
})
export class ClientAccountsModule { }
