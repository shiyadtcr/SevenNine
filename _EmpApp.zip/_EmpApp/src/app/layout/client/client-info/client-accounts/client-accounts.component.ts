import { Component, OnInit } from '@angular/core';
import { routerTransition } from '../../../../router.animations';

@Component({
  selector: 'app-client-accounts',
  templateUrl: './client-accounts.component.html',
  styleUrls: ['./client-accounts.component.scss'],
  animations: [routerTransition()]
})
export class ClientAccountsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
