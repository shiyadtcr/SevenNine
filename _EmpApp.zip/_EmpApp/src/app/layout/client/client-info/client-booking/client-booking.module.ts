import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FullCalendarModule } from 'ng-fullcalendar';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {SelectModule} from 'ng2-select';

import { ClientInfoService } from '../client-info.service';
import { ClientBookingRoutingModule } from './client-booking-routing.module';
import { ClientBookingComponent } from './client-booking.component';
@NgModule({
  imports: [
    CommonModule, ClientBookingRoutingModule, FullCalendarModule, NgbModule.forRoot(), FormsModule, ReactiveFormsModule, SelectModule
  ],
  declarations: [ ClientBookingComponent ],
  providers: [ ClientInfoService ]
})
export class ClientBookingModule { }
