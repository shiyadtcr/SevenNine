import { Component, OnInit } from '@angular/core';
import { routerTransition } from '../../../../router.animations';
import { AppService } from '../../../../shared';
@Component({
  selector: 'app-client-details',
  templateUrl: './client-details.component.html',
  styleUrls: ['./client-details.component.scss'],
  animations: [routerTransition()]
})
export class ClientDetailsComponent implements OnInit {
  selectedClient:string = this.appService.getSessionData('selected-client-title');
  selectedBranch:string = this.appService.getSessionData('selected-branch-title');
  
  constructor(
    private appService: AppService
  ) { }

  ngOnInit() {
    
  }

}
