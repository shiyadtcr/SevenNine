import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TranslateModule } from '@ngx-translate/core';

import { ClientRoutingModule } from '../client-routing.module';
import { ClientInfoComponent } from './client-info.component';
import { AppService } from '../../../shared';

@NgModule({
  imports: [
    CommonModule, ClientRoutingModule, TranslateModule
  ],
  declarations: [ ClientInfoComponent ],
  providers: [ ]
})
export class ClientInfoModule { 
  constructor(
    private appService:AppService
  ) { 
    this.appService.setSessionData('main-module','client'); 
  }
}
