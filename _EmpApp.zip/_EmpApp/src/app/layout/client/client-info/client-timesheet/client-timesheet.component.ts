import { Component, OnInit } from '@angular/core';
import { routerTransition } from '../../../../router.animations';
import { AppService } from '../../../../shared';

@Component({
  selector: 'app-client-timesheet',
  templateUrl: './client-timesheet.component.html',
  styleUrls: ['./client-timesheet.component.scss'],
  animations: [routerTransition()]
})
export class ClientTimesheetComponent implements OnInit {
  selectedClient:string = this.appService.getSessionData('selected-client-title');
  selectedBranch:string = this.appService.getSessionData('selected-branch-title');
  constructor(
    private appService: AppService
  ) { }

  ngOnInit() {
  }
  viewTimesheet(view){
    this.appService.openPopup(view,{ size: 'lg' });
  }
}
