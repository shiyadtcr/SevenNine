import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';


import { ClientTimesheetRoutingModule } from './client-timesheet-routing.module';
import { ClientTimesheetComponent } from './client-timesheet.component';
@NgModule({
  imports: [
    CommonModule, ClientTimesheetRoutingModule
  ],
  declarations: [ ClientTimesheetComponent ]
})
export class ClientTimesheetModule { }
