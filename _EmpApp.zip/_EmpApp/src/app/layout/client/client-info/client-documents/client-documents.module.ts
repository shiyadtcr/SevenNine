import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';


import { ClientDocumentsRoutingModule } from './client-documents-routing.module';
import { ClientDocumentsComponent } from './client-documents.component';
@NgModule({
  imports: [
    CommonModule, ClientDocumentsRoutingModule
  ],
  declarations: [ ClientDocumentsComponent ]
})
export class ClientDocumentsModule { }
