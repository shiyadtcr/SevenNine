import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ClientDocumentsComponent } from './client-documents.component';

const routes: Routes = [
    {
        path: '',
        component: ClientDocumentsComponent
    }
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  declarations: []
})
export class ClientDocumentsRoutingModule { }