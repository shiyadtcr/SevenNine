import { Component, OnInit } from '@angular/core';
import { routerTransition } from '../../../../router.animations';

@Component({
  selector: 'app-client-documents',
  templateUrl: './client-documents.component.html',
  styleUrls: ['./client-documents.component.scss'],
  animations: [routerTransition()]
})
export class ClientDocumentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
