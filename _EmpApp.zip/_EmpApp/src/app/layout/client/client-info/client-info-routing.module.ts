import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ClientInfoComponent } from './client-info.component';

const routes: Routes = [
	{
		path: '',
		component: ClientInfoComponent,
		children: [
			{ path: '', redirectTo: 'details' },
			{ path: 'details', loadChildren: './client-details/client-details.module#ClientDetailsModule'},
			{ path: 'booking', loadChildren: './client-booking/client-booking.module#ClientBookingModule'},
			{ path: 'timesheet', loadChildren: './client-timesheet/client-timesheet.module#ClientTimesheetModule'},
			{ path: 'documents', loadChildren: './client-documents/client-documents.module#ClientDocumentsModule'},
			{ path: 'accounts', loadChildren: './client-accounts/client-accounts.module#ClientAccountsModule'}
		]
	}
];
@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  exports:[ RouterModule ],
  declarations: []
})
export class ClientInfoRoutingModule { }
