import { Component, OnInit } from '@angular/core';
import { routerTransition } from '../../../router.animations';
import { AppService } from '../../../shared';
import { ClientService } from '../client.service'
@Component({
  selector: 'app-client-list',
  templateUrl: './client-list.component.html',
  styleUrls: ['./client-list.component.scss'],
  animations: [routerTransition()]
})
export class ClientListComponent implements OnInit {
  clientList:any;
  selectedBranch:string = '';
  pageTitle:string  =   'Clients';
  constructor(
    private appService:AppService,
    private clientService:ClientService
  ) {
    this.clientList = this.clientService.getAllClients();
    if(this.appService.getSessionData('selected-branch-id')){
      this.selectedBranch = this.appService.getSessionData('selected-branch-id');
      this.pageTitle = this.appService.getSessionData('selected-branch-title');
    }
   }

  ngOnInit() {
  }

}
