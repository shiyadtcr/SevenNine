import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ClientListRoutingModule } from './client-list-routing.module';
import { ClientListComponent } from './client-list.component';
import { StatClientModule } from '../shared';

@NgModule({
  imports: [
    CommonModule, ClientListRoutingModule, StatClientModule
  ],
  declarations: [ ClientListComponent ]
})
export class ClientListModule { }
