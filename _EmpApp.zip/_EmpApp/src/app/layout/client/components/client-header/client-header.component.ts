import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';

@Component({
    selector: 'app-client-header',
    templateUrl: './client-header.component.html',
    styleUrls: ['./client-header.component.scss']
})
export class ClientHeaderComponent implements OnInit {
    navHeight:number = 0;
    constructor(private translate: TranslateService, public router: Router) {

        this.translate.addLangs(['en', 'fr', 'ur', 'es', 'it', 'fa', 'de', 'zh-CHS']);
        this.translate.setDefaultLang('en');
        const browserLang = this.translate.getBrowserLang();
        this.translate.use(browserLang.match(/en|fr|ur|es|it|fa|de|zh-CHS/) ? browserLang : 'en');

    }

    ngOnInit() {}
    getActiveClass(v){
        let _active = '';
        let _url = this.router.url;
        if(_url.indexOf(v) != -1){
            _active = 'active'
        }
        return _active;
    }
    toggleMenu() {
        this.navHeight  = this.navHeight == 0 ? 350 : 0;
    }

    changeLang(language: string) {
        this.translate.use(language);
    }
}
