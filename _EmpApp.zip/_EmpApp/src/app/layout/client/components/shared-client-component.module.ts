import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { RouterModule } from '@angular/router';
import { AppService } from '../../../shared';

import { ClientHeaderComponent } from './client-header/client-header.component';
@NgModule({
  imports: [
    CommonModule, TranslateModule, RouterModule
  ],
  declarations: [ 
    ClientHeaderComponent
  ],
  exports: [
    ClientHeaderComponent, TranslateModule, RouterModule, 
  ],
  providers: [AppService]
})
export class SharedClientComponentModule { }
