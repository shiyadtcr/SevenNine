import { Injectable } from '@angular/core';

@Injectable()
export class ClientService {
allClients: any = [
   {
      id:1,
      title:'Capital Company Ltd',
      logo:'assets/images/clients/capital.png',
      type:'Investment',
      description:'Test 123'
    },
    {
      id:2,
      title:'Golden Ratio',
      logo:'assets/images/clients/golden-ratio.png',
      type:'Nature Design',
      description:'Test 123'
    },
    {
      id:3,
      title:'Mirana',
      logo:'assets/images/clients/mirana.png',
      type:'Food Industry',
      description:'Test 123'
    },
    {
      id:4,
      title:'Parrot Company Ltd',
      logo:'assets/images/clients/parrot.png',
      type:'Clinic',
      description:'Test 123'
    }
  ];
  clientDetails:any = {
    area:'Kunnamkulam',
    addrLine1:'Cherath (H)',
    addrLine2:'Korattikkara PO',
    city:'Thrissur',
    username:'shiyad',
    pwd:'Test@123',
    image:'',
    pin:'680543',
    phone:'0000',
    mob:'+918129796790',
    fax:'0000',
    contactPerson:'jomi',
    email:'shiyad.tcr@gmail.com'
  };
  constructor() { }
  getClientDetailsById(id){
    return this.clientDetails;
  }
  getAllClients(){
    return this.allClients;
  }
}
