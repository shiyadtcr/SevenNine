import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ClientComponent } from './client.component';
import { ClientInfoComponent } from './client-info/client-info.component';

const routes: Routes = [
	{
		path: '',
		component: ClientComponent,
		children: [
			{ path: '', redirectTo: 'home' },
			{ path: 'home', loadChildren: './home/client-list.module#ClientListModule'},
			{ path: 'add', loadChildren: './add-client/add-client.module#AddClientModule'},
			{
        path: '',
				loadChildren: './client-info/client-info.module#ClientInfoModule',
        children: [
            { path: '', redirectTo: 'details' },
						{ path: 'details', loadChildren: './client-info/client-details/client-details.module#ClientDetailsModule'},
						{ path: 'booking', loadChildren: './client-info/client-booking/client-booking.module#ClientBookingModule'},
						{ path: 'timesheet', loadChildren: './client-info/client-timesheet/client-timesheet.module#ClientTimesheetModule'},
						{ path: 'documents', loadChildren: './client-info/client-documents/client-documents.module#ClientDocumentsModule'},
						{ path: 'accounts', loadChildren: './client-info/client-accounts/client-accounts.module#ClientAccountsModule'}
        ]
    }
		]
	}
];
@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  exports:[ RouterModule ],
  declarations: []
})
export class ClientRoutingModule { }
