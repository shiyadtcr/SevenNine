import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AddClientRoutingModule } from './add-client-routing.module';
import { AddClientComponent } from './add-client.component';

@NgModule({
  imports: [
    CommonModule, AddClientRoutingModule, FormsModule, ReactiveFormsModule
  ],
  declarations: [ AddClientComponent ]
})
export class AddClientModule { }
