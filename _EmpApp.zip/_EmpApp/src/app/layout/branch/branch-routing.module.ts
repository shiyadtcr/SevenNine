import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { BranchComponent } from './branch.component';

const routes: Routes = [
	{
		path: '',
		component: BranchComponent,
		children: [
			{ path: '', redirectTo: 'home' },
			{ path: 'home', loadChildren: './home/branch-list.module#BranchListModule'},
			{ path: 'add', loadChildren: './add-branch/add-branch.module#AddBranchModule'}
		]
	}
];
@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  exports:[ RouterModule ],
  declarations: []
})
export class BranchRoutingModule { }
