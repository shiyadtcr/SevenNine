import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TranslateModule } from '@ngx-translate/core';
import { BranchRoutingModule } from './branch-routing.module';
import { BranchComponent } from './branch.component';
import { AppService } from '../../shared';
import { BranchService } from './branch.service';


@NgModule({
  imports: [
    CommonModule, BranchRoutingModule, TranslateModule
  ],
  declarations: [ BranchComponent ],
  providers:[BranchService]
})
export class BranchModule {
  constructor(
    private appService:AppService
  ) { 
    this.appService.setSessionData('main-module','branch');
  }
}
