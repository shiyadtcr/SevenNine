import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from '../../../../../shared';

@Component({
    selector: 'app-stat-branch',
    templateUrl: './stat-branch.component.html',
    styleUrls: ['./stat-branch.component.scss']
})
export class StatBranchComponent implements OnInit {
    @Input() bgClass: string;
    @Input() icon: string;
    @Input() count: number;
    @Input() label: string;
    @Input() data: number;
    @Input() branchData: any;
    @Output() event: EventEmitter<any> = new EventEmitter();

    constructor(
        private router : Router,
        private appService:AppService
    ) {}
    setSelectedBranch(){
        this.appService.setSessionData('selected-branch-id',this.branchData.id);
        this.appService.setSessionData('selected-branch-title',this.branchData.title);
    }
    navigateToClient(){
        this.setSelectedBranch();
        this.router.navigate(['client']);
    }
    editBranch(){
        this.setSelectedBranch();
        this.appService.setSessionData('edit-branch-mode',true);
        this.router.navigate(['add']);
    }
    openViewPopup(viewBranchContent){
        this.appService.openPopup(viewBranchContent,null);
    }
    ngOnInit() {}
}
