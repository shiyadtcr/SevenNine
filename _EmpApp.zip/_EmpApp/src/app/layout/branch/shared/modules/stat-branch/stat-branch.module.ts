import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { StatBranchComponent } from './stat-branch.component';

@NgModule({
    imports: [CommonModule,RouterModule],
    declarations: [StatBranchComponent],
    exports: [StatBranchComponent]
})
export class StatBranchModule {}
