import { StatModule } from './stat-branch.module';

describe('StatBranchModule', () => {
    let statModule: StatBranchModule;

    beforeEach(() => {
        statBranchModule = new StatBranchModule();
    });

    it('should create an instance', () => {
        expect(staBranchtModule).toBeTruthy();
    });
});
