import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StatComponent } from './stat-branch.component';

describe('StatBranchComponent', () => {
    let component: StatBranchComponent;
    let fixture: ComponentFixture<StatBranchComponent>;

    beforeEach(
        async(() => {
            TestBed.configureTestingModule({
                declarations: [StatBranchComponent]
            }).compileComponents();
        })
    );

    beforeEach(() => {
        fixture = TestBed.createComponent(StatBranchComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
