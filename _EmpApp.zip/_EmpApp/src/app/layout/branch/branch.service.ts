import { Injectable } from '@angular/core';

@Injectable()
export class BranchService {
  allBranches: any = [
     {
      id:1,
      title:'Thrissur',
      logo:'assets/images/clients/capital.png',
      type:'Investment',
      description:'Test 123'
    },
    {
      id:2,
      title:'Kunnamkulam',
      logo:'assets/images/clients/capital.png',
      type:'Investment',
      description:'Test 123'
    },
    {
      id:3,
      title:'Cochin',
      logo:'assets/images/clients/capital.png',
      type:'Investment',
      description:'Test 123'
    },
    {
      id:4,
      title:'Kozhikkodu',
      logo:'assets/images/clients/capital.png',
      type:'Investment',
      description:'Test 123'
    },
    {
      id:5,
      title:'Kannur',
      logo:'assets/images/clients/capital.png',
      type:'Investment',
      description:'Test 123'
    }    
  ];
  branchDetails:any = {
    area:'Kunnamkulam',
    addrLine1:'Cherath (H)',
    addrLine2:'Korattikkara PO',
    city:'Thrissur',
    username:'shiyad',
    pwd:'Test@123',
    image:'',
    pin:'680543',
    phone:'0000',
    mob:'+918129796790',
    fax:'0000',
    contactPerson:'jomi',
    email:'shiyad.tcr@gmail.com'
  };
  constructor() { }
  getBranchDetailsById(id){
    return this.branchDetails;
  }
  getAllBranches(){
    return this.allBranches;
  }
}
