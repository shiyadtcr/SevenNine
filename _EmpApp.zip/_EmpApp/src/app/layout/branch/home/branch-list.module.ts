import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BranchListRoutingModule } from './branch-list-routing.module';
import { BranchListComponent } from './branch-list.component';
import { StatBranchModule } from '../shared';

@NgModule({
  imports: [
    CommonModule, BranchListRoutingModule, StatBranchModule
  ],
  declarations: [ BranchListComponent ]
})
export class BranchListModule { }
