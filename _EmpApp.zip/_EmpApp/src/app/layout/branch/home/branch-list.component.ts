import { Component, OnInit } from '@angular/core';
import { routerTransition } from '../../../router.animations';
import { BranchService } from '../branch.service'
@Component({
  selector: 'app-branch-list',
  templateUrl: './branch-list.component.html',
  styleUrls: ['./branch-list.component.scss'],
  animations: [routerTransition()]
})
export class BranchListComponent implements OnInit {
  branchList:any;
  constructor(
    private branchService:BranchService
  ) { 
    this.branchList = this.branchService.getAllBranches();
  }

  ngOnInit() {
  }

}
