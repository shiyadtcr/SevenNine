import { Component, OnInit } from '@angular/core';
import { AppService } from '../../shared';

@Component({
  selector: 'app-branch',
  templateUrl: './branch.component.html',
  styleUrls: ['./branch.component.scss']
})
export class BranchComponent implements OnInit {

  constructor(
    private appService:AppService
  ) { }

  ngOnInit() {
    this.appService.removeSessionData('hasClientSelected'); 
  }

}
