import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { routerTransition } from '../../../router.animations';
import { AppService } from '../../../shared';
import { BranchService } from '../branch.service';
@Component({
  selector: 'app-add-branch',
  templateUrl: './add-branch.component.html',
  styleUrls: ['./add-branch.component.scss'],
  animations: [routerTransition()]
})
export class AddBranchComponent implements OnInit {
  branchAddressFormGroup:FormGroup;
  selectedEditBranch:string = 'Branch';
  editMode:string = 'false';
  constructor(
    private addressForm: FormBuilder,
    private appService:AppService,
    private branchService:BranchService
  ) {     
    this.selectedEditBranch = this.appService.getSessionData('selected-branch-title');
    this.editMode = this.appService.getSessionData  ('edit-branch-mode');
    this.branchAddressFormGroup = this.addressForm.group({
      area: ['', Validators.required ],
      addrLine1: ['', Validators.required ],
      addrLine2: [''],
      city: ['', Validators.required ],
      username: ['', Validators.required ],
      pwd: ['', Validators.required ],
      image: [''],
      pin: ['', Validators.required ],
      phone: [''],
      mob: ['', Validators.required ],
      fax: [''],
      contactPerson: ['', Validators.required ],
      email: ['', Validators.required ]
    });
  }
  get _area() { return this.branchAddressFormGroup.get('area'); }
  get _addrLine1() { return this.branchAddressFormGroup.get('addrLine1'); }
  get _addrLine2() { return this.branchAddressFormGroup.get('addrLine2'); }
  get _city() { return this.branchAddressFormGroup.get('city'); }
  get _username() { return this.branchAddressFormGroup.get('username'); }
  get _pwd() { return this.branchAddressFormGroup.get('pwd'); }
  get _image() { return this.branchAddressFormGroup.get('image'); }
  get _pin() { return this.branchAddressFormGroup.get('pin'); }
  get _phone() { return this.branchAddressFormGroup.get('phone'); }
  get _mob() { return this.branchAddressFormGroup.get('mob'); }
  get _fax() { return this.branchAddressFormGroup.get('fax'); }
  get _contactPerson() { return this.branchAddressFormGroup.get('contactPerson'); }
  get _email() { return this.branchAddressFormGroup.get('email'); }
  set _area(value:any) { this._area.value = value; }
  set _addrLine1(value:any) { this._addrLine1.value = value; }
  set _addrLine2(value:any) { this._area.value = value; }
  set _city(value:any) { this._area.value = value; }
  set _username(value:any) { this._area.value = value; }
  set _pwd(value:any) { this._area.value = value; }
  set _image(value:any) { this._area.value = value; }
  set _pin(value:any) { this._area.value = value; }
  set _phone(value:any) { this._area.value = value; }
  set _mob(value:any) { this._area.value = value; }
  set _fax(value:any) { this._area.value = value; }
  set _contactPerson(value:any) { this._area.value = value; }  
  set _email(value:any) { this._area.value = value; }
  isError(field){
	  return field.invalid && (field.dirty || field.touched);
  }
  onSubmitBranch(){
    let _branchArrd = {
      area:this._area.value,		
      addrLine1:this._addrLine1.value,
      addrLine2:this._addrLine2.value,
      city:this._city.value,
      username:this._username.value,
      pwd:this._pwd.value,
      image:this._image.value,
      pin:this._pin.value,
      phone:this._phone.value,
      mob:this._mob.value,
      fax:this._fax.value,
      contactPerson:this._contactPerson.value,
      email:this._email.value
	  }
    console.log('Branch Form Request Data: ',_branchArrd);
  }
  ngOnInit() {
    if(this.editMode == 'true'){
      let branchData = this.branchService.getBranchDetailsById('');
      this._area.value = branchData.area;
      this._addrLine1.value = branchData.addrLine1;
      this._addrLine2.value = branchData.addrLine2;
      this._city.value = branchData.city;
      this._username.value = branchData.username;
      this._pwd.value = branchData.pwd;
      this._image.value = branchData.image;
      this._pin.value = branchData.pin;
      this._phone.value = branchData.phone;
      this._mob.value = branchData.mob;
      this._fax.value = branchData.fax;
      this._contactPerson.value = branchData.contactPerson;
      this._email.value = branchData.email;
    }
  }
  ngOnDestroy(){
    this.appService.setSessionData('edit-branch-mode',false);
  }  

}
