import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AddBranchRoutingModule } from './add-branch-routing.module';
import { AddBranchComponent } from './add-branch.component';

@NgModule({
  imports: [
    CommonModule, AddBranchRoutingModule, FormsModule, ReactiveFormsModule
  ],
  declarations: [ AddBranchComponent ]
})
export class AddBranchModule { }
